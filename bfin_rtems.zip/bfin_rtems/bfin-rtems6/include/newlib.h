/* newlib.h.  Generated from newlib.hin by configure.  */
/* newlib.hin.  Generated from configure.ac by autoheader.  */

/* NB: The contents are filtered before being installed. */

#ifndef __NEWLIB_H__
#define __NEWLIB_H__ 1

/* Newlib version */
#include <_newlib_version.h>

/* Define to 1 if the system has the type `long double'. */

/* Define to the address where bug reports for this package should be sent. */

/* Define to the full name of this package. */

/* Define to the full name and version of this package. */

/* Define to the one symbol short name of this package. */

/* Define to the home page for this package. */

/* Define to the version of this package. */

/* If atexit() may dynamically allocate space for cleanup functions. */
#define _ATEXIT_DYNAMIC_ALLOC 1

/* EL/IX level */
/* #undef _ELIX_LEVEL */

/* Define if fseek functions support seek optimization. */
#define _FSEEK_OPTIMIZATION 1

/* Define if ivo supported in streamio. */
#define _FVWRITE_IN_STREAMIO 1

/* Define if compiler supports -fno-tree-loop-distribute-patterns. */
#define _HAVE_CC_INHIBIT_LOOP_TO_LIBCALL 1

/* Define if the linker supports .preinit_array/.init_array/.fini_array
   sections. */
#define _HAVE_INITFINI_ARRAY 1

/* Define if the platform supports long double type. */
#define _HAVE_LONG_DOUBLE 1

/* ICONV enabled. */
#define _ICONV_ENABLED 1

/* Enable ICONV external CCS files loading capabilities. */
/* #undef _ICONV_ENABLE_EXTERNAL_CCS */

/* Support big5 input encoding. */
#define _ICONV_FROM_ENCODING_BIG5 1

/* Support cp775 input encoding. */
#define _ICONV_FROM_ENCODING_CP775 1

/* Support cp850 input encoding. */
#define _ICONV_FROM_ENCODING_CP850 1

/* Support cp852 input encoding. */
#define _ICONV_FROM_ENCODING_CP852 1

/* Support cp855 input encoding. */
#define _ICONV_FROM_ENCODING_CP855 1

/* Support cp866 input encoding. */
#define _ICONV_FROM_ENCODING_CP866 1

/* Support euc_jp input encoding. */
#define _ICONV_FROM_ENCODING_EUC_JP 1

/* Support euc_kr input encoding. */
#define _ICONV_FROM_ENCODING_EUC_KR 1

/* Support euc_tw input encoding. */
#define _ICONV_FROM_ENCODING_EUC_TW 1

/* Support iso_8859_1 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_1 1

/* Support iso_8859_10 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_10 1

/* Support iso_8859_11 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_11 1

/* Support iso_8859_13 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_13 1

/* Support iso_8859_14 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_14 1

/* Support iso_8859_15 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_15 1

/* Support iso_8859_2 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_2 1

/* Support iso_8859_3 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_3 1

/* Support iso_8859_4 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_4 1

/* Support iso_8859_5 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_5 1

/* Support iso_8859_6 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_6 1

/* Support iso_8859_7 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_7 1

/* Support iso_8859_8 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_8 1

/* Support iso_8859_9 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_8859_9 1

/* Support iso_ir_111 input encoding. */
#define _ICONV_FROM_ENCODING_ISO_IR_111 1

/* Support koi8_r input encoding. */
#define _ICONV_FROM_ENCODING_KOI8_R 1

/* Support koi8_ru input encoding. */
#define _ICONV_FROM_ENCODING_KOI8_RU 1

/* Support koi8_u input encoding. */
#define _ICONV_FROM_ENCODING_KOI8_U 1

/* Support koi8_uni input encoding. */
#define _ICONV_FROM_ENCODING_KOI8_UNI 1

/* Support ucs_2 input encoding. */
#define _ICONV_FROM_ENCODING_UCS_2 1

/* Support ucs_2be input encoding. */
#define _ICONV_FROM_ENCODING_UCS_2BE 1

/* Support ucs_2le input encoding. */
#define _ICONV_FROM_ENCODING_UCS_2LE 1

/* Support ucs_2_internal input encoding. */
#define _ICONV_FROM_ENCODING_UCS_2_INTERNAL 1

/* Support ucs_4 input encoding. */
#define _ICONV_FROM_ENCODING_UCS_4 1

/* Support ucs_4be input encoding. */
#define _ICONV_FROM_ENCODING_UCS_4BE 1

/* Support ucs_4le input encoding. */
#define _ICONV_FROM_ENCODING_UCS_4LE 1

/* Support ucs_4_internal input encoding. */
#define _ICONV_FROM_ENCODING_UCS_4_INTERNAL 1

/* Support us_ascii input encoding. */
#define _ICONV_FROM_ENCODING_US_ASCII 1

/* Support utf_16 input encoding. */
#define _ICONV_FROM_ENCODING_UTF_16 1

/* Support utf_16be input encoding. */
#define _ICONV_FROM_ENCODING_UTF_16BE 1

/* Support utf_16le input encoding. */
#define _ICONV_FROM_ENCODING_UTF_16LE 1

/* Support utf_8 input encoding. */
#define _ICONV_FROM_ENCODING_UTF_8 1

/* Support win_1250 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1250 1

/* Support win_1251 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1251 1

/* Support win_1252 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1252 1

/* Support win_1253 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1253 1

/* Support win_1254 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1254 1

/* Support win_1255 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1255 1

/* Support win_1256 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1256 1

/* Support win_1257 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1257 1

/* Support win_1258 input encoding. */
#define _ICONV_FROM_ENCODING_WIN_1258 1

/* Support big5 output encoding. */
#define _ICONV_TO_ENCODING_BIG5 1

/* Support cp775 output encoding. */
#define _ICONV_TO_ENCODING_CP775 1

/* Support cp850 output encoding. */
#define _ICONV_TO_ENCODING_CP850 1

/* Support cp852 output encoding. */
#define _ICONV_TO_ENCODING_CP852 1

/* Support cp855 output encoding. */
#define _ICONV_TO_ENCODING_CP855 1

/* Support cp866 output encoding. */
#define _ICONV_TO_ENCODING_CP866 1

/* Support euc_jp output encoding. */
#define _ICONV_TO_ENCODING_EUC_JP 1

/* Support euc_kr output encoding. */
#define _ICONV_TO_ENCODING_EUC_KR 1

/* Support euc_tw output encoding. */
#define _ICONV_TO_ENCODING_EUC_TW 1

/* Support iso_8859_1 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_1 1

/* Support iso_8859_10 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_10 1

/* Support iso_8859_11 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_11 1

/* Support iso_8859_13 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_13 1

/* Support iso_8859_14 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_14 1

/* Support iso_8859_15 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_15 1

/* Support iso_8859_2 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_2 1

/* Support iso_8859_3 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_3 1

/* Support iso_8859_4 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_4 1

/* Support iso_8859_5 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_5 1

/* Support iso_8859_6 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_6 1

/* Support iso_8859_7 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_7 1

/* Support iso_8859_8 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_8 1

/* Support iso_8859_9 output encoding. */
#define _ICONV_TO_ENCODING_ISO_8859_9 1

/* Support iso_ir_111 output encoding. */
#define _ICONV_TO_ENCODING_ISO_IR_111 1

/* Support koi8_r output encoding. */
#define _ICONV_TO_ENCODING_KOI8_R 1

/* Support koi8_ru output encoding. */
#define _ICONV_TO_ENCODING_KOI8_RU 1

/* Support koi8_u output encoding. */
#define _ICONV_TO_ENCODING_KOI8_U 1

/* Support koi8_uni output encoding. */
#define _ICONV_TO_ENCODING_KOI8_UNI 1

/* Support ucs_2 output encoding. */
#define _ICONV_TO_ENCODING_UCS_2 1

/* Support ucs_2be output encoding. */
#define _ICONV_TO_ENCODING_UCS_2BE 1

/* Support ucs_2le output encoding. */
#define _ICONV_TO_ENCODING_UCS_2LE 1

/* Support ucs_2_internal output encoding. */
#define _ICONV_TO_ENCODING_UCS_2_INTERNAL 1

/* Support ucs_4 output encoding. */
#define _ICONV_TO_ENCODING_UCS_4 1

/* Support ucs_4be output encoding. */
#define _ICONV_TO_ENCODING_UCS_4BE 1

/* Support ucs_4le output encoding. */
#define _ICONV_TO_ENCODING_UCS_4LE 1

/* Support ucs_4_internal output encoding. */
#define _ICONV_TO_ENCODING_UCS_4_INTERNAL 1

/* Support us_ascii output encoding. */
#define _ICONV_TO_ENCODING_US_ASCII 1

/* Support utf_16 output encoding. */
#define _ICONV_TO_ENCODING_UTF_16 1

/* Support utf_16be output encoding. */
#define _ICONV_TO_ENCODING_UTF_16BE 1

/* Support utf_16le output encoding. */
#define _ICONV_TO_ENCODING_UTF_16LE 1

/* Support utf_8 output encoding. */
#define _ICONV_TO_ENCODING_UTF_8 1

/* Support win_1250 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1250 1

/* Support win_1251 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1251 1

/* Support win_1252 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1252 1

/* Support win_1253 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1253 1

/* Support win_1254 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1254 1

/* Support win_1255 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1255 1

/* Support win_1256 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1256 1

/* Support win_1257 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1257 1

/* Support win_1258 output encoding. */
#define _ICONV_TO_ENCODING_WIN_1258 1

/* Define if the platform long double type is equal to double. */
#define _LDBL_EQ_DBL 1

/* Define if lite version of exit supported. */
/* #undef _LITE_EXIT */

/* Multibyte supported. */
/* #undef _MB_CAPABLE */

/* Multibyte max length. */
#define _MB_LEN_MAX 1

/* Define if small footprint nano-formatted-IO implementation used. */
/* #undef _NANO_FORMATTED_IO */

/* nano version of malloc is used. */
/* #undef _NANO_MALLOC */

/* The newlib version in string format. */
#define _NEWLIB_VERSION "4.3.0"

/* Verify _REENT_CHECK macros allocate memory successfully. */
#define _REENT_CHECK_VERIFY 1

/* Define if using retargetable functions for default lock routines. */
/* #undef _RETARGETABLE_LOCKING */

/* Define if unbuffered stream file optimization is supported. */
#define _UNBUF_STREAM_OPT 1

/* Enable C99 formats support (e.g. %a, %zu, ...) in IO functions like
   printf/scanf. */
#define _WANT_IO_C99_FORMATS 1

/* Define to enable long double type support in IO functions like
   printf/scanf. */
/* #undef _WANT_IO_LONG_DOUBLE */

/* Define to enable long long type support in IO functions like printf/scanf.
   */
#define _WANT_IO_LONG_LONG 1

/* Positional argument support in printf functions enabled. */
/* #undef _WANT_IO_POS_ARGS */

/* Define to enable backward binary compatibility for struct _reent. */
/* #undef _WANT_REENT_BACKWARD_BINARY_COMPAT */

/* Optional reentrant struct support. Used mostly on platforms with very
   restricted storage. */
/* #undef _WANT_REENT_SMALL */

/* Define to enable thread-local storage objects as a replacment for struct
   _reent members. */
/* #undef _WANT_REENT_THREAD_LOCAL */

/* Register application finalization function using atexit. */
/* #undef _WANT_REGISTER_FINI */

/* Define if using gdtoa rather than legacy ldtoa. */
#define _WANT_USE_GDTOA 1

/* Define to use type long for time_t. */
/* #undef _WANT_USE_LONG_TIME_T */

/* Define if wide char orientation is supported. */
#define _WIDE_ORIENT 1

/* The newlib minor version number. */
#define __NEWLIB_MINOR__ 3

/* The newlib patch level. */
#define __NEWLIB_PATCHLEVEL__ 0

/* The newlib major version number. */
#define __NEWLIB__ 4

#endif /* !__NEWLIB_H__ */
